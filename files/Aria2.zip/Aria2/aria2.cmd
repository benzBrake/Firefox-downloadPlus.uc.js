@echo off
setlocal
"%~dp0aria2c.exe" %*
set "exitCode=%errorlevel%"
echo.
pause
exit /b %exitCode%
